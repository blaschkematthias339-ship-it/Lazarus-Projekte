OpenLazarusSetup 1.2
====================
Lazarus-Projekt für Ubuntu, Kubuntu und KDE neon.

NEU IN VERSION 1.2
------------------
* ZIP-Paket zur Veröffentlichung mit einer .run-Datei und INSTALLATION.txt.
* Optionale automatische ZIP-Erstellung nach erfolgreicher RUN-Erstellung.
* Vorhandene .run-Dateien direkt über die Oberfläche als ZIP verpacken.
* Ausgabeordner und Dateiname werden automatisch übernommen.
* Bereits vorhandene ZIP-Dateien werden nur nach Bestätigung überschrieben.
* Die enthaltene .run-Datei behält ihr Ausführungsrecht im Archiv; die
  Anleitung enthält zusätzlich den portablen chmod-Befehl.
* Die Funktionen aus Version 1.1 bleiben erhalten.

ANWENDUNG
---------
1. OpenLazarusSetup.lpi in Lazarus öffnen und kompilieren.
2. Programmdatei, Name, Version, Paketname und Ausgabeordner wählen.
3. Checkbox "Nach DEB-Erstellung ... RUN-Datei" aktivieren.
4. Checkbox "Zusätzlich ZIP-Archiv ..." aktivieren.
5. "DEB-Installationspaket erstellen" drücken.
   Ergebnis: .deb, .run und .zip mit Installationsanleitung.

Alternativ:
- Vorhandene DEB wählen, ZIP-Checkbox aktivieren und RUN erstellen.
- Vorhandene RUN wählen und "Aus vorhandener RUN-Datei ... ZIP" drücken.

INSTALLATION BEIM EMPFÄNGER
---------------------------
ZIP entpacken, Terminal im entpackten Ordner öffnen und ausführen:
   chmod +x -- ./DATEINAME-Setup.run
   ./DATEINAME-Setup.run
Das Installationsprogramm fragt um Erlaubnis und benötigt für apt-get
Administrationsrechte. Bitte nur vertrauenswürdige Dateien ausführen.

VORAUSSETZUNGEN
---------------
Bauen: Lazarus/FPC, dpkg-deb (DEB), sha256sum (RUN), zip (ZIP).
Das ZIP-Werkzeug lässt sich mit "sudo apt install zip" installieren.
Empfänger: Debian/Ubuntu mit apt-get und den in Version 1.1 beschriebenen
Kommandos (sha256sum, awk, tail, mktemp, pkexec oder sudo, ggf. kdialog/zenity).

HINWEISE
--------
- Das ZIP ist kein zusätzliches Installationsformat, sondern bündelt die RUN
  mit einer verständlichen Anleitung zum öffentlichen Herunterladen.
- Für die Installation ist keine ZIP-Software außer dem Entpack-Werkzeug nötig.
- SHA256 innerhalb der RUN schützt vor Übertragungsfehlern, nicht vor
  absichtlicher Manipulation; im Zweifel eine separate signierte Prüfsumme
  oder ein vertrauenswürdiges Hosting verwenden.
- Die RUN ist weiterhin eine eigenständige Datei, die das DEB enthält.
- Erste DEB-Baufunktion unterstützt weiterhin nur eine Programmdatei.
- Ein installiertes Lazarus/FPC war in der Erstellungsumgebung nicht
  vorhanden; das Projekt muss in der Lazarus-IDE kompiliert/getestet werden.
