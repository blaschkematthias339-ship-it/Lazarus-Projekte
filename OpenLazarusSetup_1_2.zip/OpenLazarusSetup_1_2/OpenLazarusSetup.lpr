program OpenLazarusSetup;

{$mode objfpc}{$H+}

uses
  Interfaces, Forms, MainUnit;

begin
  RequireDerivedFormResource := True;
  Application.Scaled := True;
  Application.Initialize;
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
