unit MainUnit;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls,
  ExtCtrls, Process, BaseUnix, FileUtil;

type
  TMainForm = class(TForm)
    BtnBuild: TButton;
    BtnBrowseDeb: TButton;
    BtnBuildRun: TButton;
    ChkBuildRun: TCheckBox;
    ChkBuildZip: TCheckBox;
    EdRunFile: TEdit;
    LabelRunFile: TLabel;
    BtnBrowseRun: TButton;
    BtnBuildZip: TButton;
    OpenRunDialog: TOpenDialog;
    EdDebFile: TEdit;
    LabelDebFile: TLabel;
    OpenDebDialog: TOpenDialog;
    BtnBrowseExe: TButton;
    BtnBrowseIcon: TButton;
    BtnBrowseOutput: TButton;
    ChkTerminal: TCheckBox;
    EdArchitecture: TComboBox;
    EdCategory: TComboBox;
    EdDescription: TEdit;
    EdExecutable: TEdit;
    EdIcon: TEdit;
    EdMaintainer: TEdit;
    EdName: TEdit;
    EdOutput: TEdit;
    EdPackage: TEdit;
    EdVersion: TEdit;
    HeaderPanel: TPanel;
    LabelArch: TLabel;
    LabelCategory: TLabel;
    LabelDescription: TLabel;
    LabelExecutable: TLabel;
    LabelIcon: TLabel;
    LabelMaintainer: TLabel;
    LabelName: TLabel;
    LabelOutput: TLabel;
    LabelPackage: TLabel;
    LabelVersion: TLabel;
    LblHeader: TLabel;
    LblSubHeader: TLabel;
    MemoLog: TMemo;
    OpenExeDialog: TOpenDialog;
    OpenIconDialog: TOpenDialog;
    SelectOutputDialog: TSelectDirectoryDialog;
    procedure BtnBrowseDebClick(Sender: TObject);
    procedure BtnBrowseRunClick(Sender: TObject);
    procedure BtnBuildZipClick(Sender: TObject);
    procedure BtnBuildRunClick(Sender: TObject);
    procedure BtnBrowseExeClick(Sender: TObject);
    procedure BtnBrowseIconClick(Sender: TObject);
    procedure BtnBrowseOutputClick(Sender: TObject);
    procedure BtnBuildClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    FLastDeb: string;
    procedure Log(const S: string);
    procedure CopyFileStream(const SourceFile, TargetFile: string);
    procedure WriteUTF8File(const FileName, Content: string);
    function ValidPackageName(const S: string): Boolean;
    function ValidVersion(const S: string): Boolean;
    function SafeDesktopValue(const S: string): string;
    procedure BuildDeb;
    function BuildRun(const DebFile: string): string;
    procedure BuildZip(const RunFile: string);
    function DebSHA256(const DebFile: string): string;
    function SafeFilePart(const Value: string): string;
    procedure CopyStreamToEnd(const ASource, ADest: string);
  end;

var
  MainForm: TMainForm;

implementation

{$R *.lfm}

procedure TMainForm.FormCreate(Sender: TObject);
begin
  EdArchitecture.Items.Text := 'amd64' + LineEnding + 'arm64' + LineEnding + 'i386';
  EdArchitecture.ItemIndex := 0;
  EdCategory.Items.Text := 'Utility' + LineEnding + 'Office' + LineEnding +
    'Development' + LineEnding + 'Graphics' + LineEnding + 'System';
  EdCategory.ItemIndex := 0;
  EdVersion.Text := '1.0.0';
  EdMaintainer.Text := 'Privates Projekt';
  EdOutput.Text := GetUserDir;
  Log('Bereit. DEB-, RUN- und ZIP-Dateien erstellen.');
end;

procedure TMainForm.Log(const S: string);
begin
  MemoLog.Lines.Add(S);
  MemoLog.SelStart := Length(MemoLog.Text);
end;

procedure TMainForm.CopyFileStream(const SourceFile, TargetFile: string);
var
  Src, Dst: TFileStream;
begin
  Src := TFileStream.Create(SourceFile, fmOpenRead or fmShareDenyWrite);
  try
    Dst := TFileStream.Create(TargetFile, fmCreate);
    try
      Dst.CopyFrom(Src, 0);
    finally
      Dst.Free;
    end;
  finally
    Src.Free;
  end;
end;

procedure TMainForm.WriteUTF8File(const FileName, Content: string);
var
  S: TStringList;
begin
  S := TStringList.Create;
  try
    S.Text := Content;
    S.SaveToFile(FileName);
  finally
    S.Free;
  end;
end;

function TMainForm.ValidPackageName(const S: string): Boolean;
var
  I: Integer;
begin
  Result := (Length(S) >= 2) and (S[1] in ['a'..'z','0'..'9']);
  if not Result then Exit;
  for I := 1 to Length(S) do
    if not (S[I] in ['a'..'z','0'..'9','+','-','.']) then Exit(False);
end;

function TMainForm.ValidVersion(const S: string): Boolean;
var
  I: Integer;
begin
  Result := (S <> '') and (S[1] in ['0'..'9']);
  if not Result then Exit;
  for I := 1 to Length(S) do
    if not (S[I] in ['a'..'z','A'..'Z','0'..'9','+','-','.','~',':']) then Exit(False);
end;

function TMainForm.SafeDesktopValue(const S: string): string;
begin
  Result := StringReplace(S, #13, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, '\', '\\', [rfReplaceAll]);
end;

procedure TMainForm.BtnBrowseDebClick(Sender: TObject);
begin
  if OpenDebDialog.Execute then EdDebFile.Text := OpenDebDialog.FileName;
end;

procedure TMainForm.BtnBuildRunClick(Sender: TObject);
var
  RunFile: string;
begin
  BtnBuildRun.Enabled := False;
  try
    try
      RunFile := BuildRun(Trim(EdDebFile.Text));
      if (RunFile <> '') and ChkBuildZip.Checked then BuildZip(RunFile);
    except
      on E: Exception do
      begin
        Log('FEHLER: ' + E.Message);
        MessageDlg('RUN-Datei konnte nicht erstellt werden', E.Message, mtError, [mbOK], 0);
      end;
    end;
  finally
    BtnBuildRun.Enabled := True;
  end;
end;

procedure TMainForm.BtnBrowseRunClick(Sender: TObject);
begin
  if OpenRunDialog.Execute then EdRunFile.Text := OpenRunDialog.FileName;
end;

procedure TMainForm.BtnBuildZipClick(Sender: TObject);
begin
  BtnBuildZip.Enabled := False;
  try
    try
      BuildZip(Trim(EdRunFile.Text));
    except
      on E: Exception do
      begin
        Log('FEHLER: ' + E.Message);
        MessageDlg('ZIP-Datei konnte nicht erstellt werden', E.Message, mtError, [mbOK], 0);
      end;
    end;
  finally
    BtnBuildZip.Enabled := True;
  end;
end;

procedure TMainForm.BtnBrowseExeClick(Sender: TObject);
begin
  if OpenExeDialog.Execute then
  begin
    EdExecutable.Text := OpenExeDialog.FileName;
    if EdPackage.Text = '' then
      EdPackage.Text := LowerCase(ExtractFileName(OpenExeDialog.FileName));
    if EdName.Text = '' then
      EdName.Text := ExtractFileName(OpenExeDialog.FileName);
  end;
end;

procedure TMainForm.BtnBrowseIconClick(Sender: TObject);
begin
  if OpenIconDialog.Execute then EdIcon.Text := OpenIconDialog.FileName;
end;

procedure TMainForm.BtnBrowseOutputClick(Sender: TObject);
begin
  SelectOutputDialog.FileName := EdOutput.Text;
  if SelectOutputDialog.Execute then EdOutput.Text := SelectOutputDialog.FileName;
end;

procedure TMainForm.BtnBuildClick(Sender: TObject);
var
  RunFile: string;
begin
  BtnBuild.Enabled := False;
  try
    try
      FLastDeb := '';
      BuildDeb;
      if ChkBuildRun.Checked and (FLastDeb <> '') then
      begin
        RunFile := BuildRun(FLastDeb);
        if (RunFile <> '') and ChkBuildZip.Checked then BuildZip(RunFile);
      end;
    except
      on E: Exception do
      begin
        Log('FEHLER: ' + E.Message);
        MessageDlg('Paket konnte nicht erstellt werden', E.Message, mtError, [mbOK], 0);
      end;
    end;
  finally
    BtnBuild.Enabled := True;
  end;
end;

procedure TMainForm.BuildDeb;
var
  PackageName, VersionStr, Arch, AppName, ExePath, IconPath, IconExt: string;
  RootDir, DataDir, BinDir, AppDir, IconDir, DesktopDir: string;
  OutputDir, TargetDeb, ProgramTarget, TempBase, DesktopText, ControlText: string;
  P: TProcess;
  DesktopFile, OutputMsg: string;
  SL: TStringList;
  ExitValue: Integer;
begin
  PackageName := Trim(EdPackage.Text);
  VersionStr := Trim(EdVersion.Text);
  AppName := Trim(EdName.Text);
  ExePath := Trim(EdExecutable.Text);
  IconPath := Trim(EdIcon.Text);
  Arch := Trim(EdArchitecture.Text);
  OutputDir := Trim(EdOutput.Text);
  if not ValidPackageName(PackageName) then
    raise Exception.Create('Paketname: nur Kleinbuchstaben, Ziffern, +, - und Punkt; mindestens 2 Zeichen.');
  if not ValidVersion(VersionStr) then
    raise Exception.Create('Ungültige Versionsnummer (z. B. 1.0.0).');
  if (AppName = '') or (Pos(#10, AppName) > 0) or (Pos(#13, AppName) > 0) then
    raise Exception.Create('Bitte einen gültigen Programmnamen eingeben.');
  if (EdDescription.Text = '') or (Pos(#10, EdDescription.Text) > 0) or
     (Pos(#13, EdDescription.Text) > 0) then
    raise Exception.Create('Bitte eine einzeilige Beschreibung eingeben.');
  if (EdMaintainer.Text = '') or (Pos(#10, EdMaintainer.Text) > 0) or
     (Pos(#13, EdMaintainer.Text) > 0) then
    raise Exception.Create('Bitte den Paketbetreuer eingeben.');
  if not FileExists(ExePath) then raise Exception.Create('Programmdatei existiert nicht.');
  if (IconPath <> '') and not FileExists(IconPath) then
    raise Exception.Create('Symboldatei existiert nicht.');
  if not (Arch = 'amd64') and not (Arch = 'arm64') and not (Arch = 'i386') then
    raise Exception.Create('Bitte eine unterstützte Architektur auswählen.');
  if not DirectoryExists(OutputDir) then raise Exception.Create('Ausgabeordner existiert nicht.');
  if FindDefaultExecutablePath('dpkg-deb') = '' then
    raise Exception.Create('dpkg-deb fehlt. Bitte das Paket dpkg installieren.');

  TargetDeb := IncludeTrailingPathDelimiter(OutputDir) + PackageName + '_' +
    VersionStr + '_' + Arch + '.deb';
  if FileExists(TargetDeb) and
    (MessageDlg('Datei überschreiben?', 'Die DEB-Datei existiert bereits. Überschreiben?',
       mtConfirmation, [mbYes,mbNo], 0) <> mrYes) then Exit;

  TempBase := GetTempDir(False);
  RootDir := IncludeTrailingPathDelimiter(TempBase) + 'openlazarussetup_' +
    IntToStr(fpGetpid) + '_' + FormatDateTime('yyyymmddhhnnsszzz', Now);
  DataDir := RootDir + '/DEBIAN';
  AppDir := RootDir + '/opt/' + PackageName;
  BinDir := RootDir + '/usr/bin';
  IconDir := RootDir + '/usr/share/pixmaps';
  DesktopDir := RootDir + '/usr/share/applications';
  if not ForceDirectories(DataDir) or not ForceDirectories(AppDir) or
     not ForceDirectories(BinDir) or not ForceDirectories(DesktopDir) then
    raise Exception.Create('Arbeitsordner konnte nicht angelegt werden.');
  try
    ProgramTarget := AppDir + '/' + PackageName;
    CopyFileStream(ExePath, ProgramTarget);
    if fpChmod(PChar(ProgramTarget), &755) <> 0 then
      raise Exception.Create('Ausführungsrecht konnte nicht gesetzt werden.');

    { Launcher in /usr/bin: absolute Programmpfad, unabhängig vom Startverzeichnis }
    WriteUTF8File(BinDir + '/' + PackageName,
      '#!/bin/sh' + LineEnding + 'exec /opt/' + PackageName + '/' + PackageName + ' "$@"' + LineEnding);
    if fpChmod(PChar(BinDir + '/' + PackageName), &755) <> 0 then
      raise Exception.Create('Startskript konnte nicht ausführbar gemacht werden.');

    DesktopText := '[Desktop Entry]' + LineEnding +
      'Type=Application' + LineEnding +
      'Name=' + SafeDesktopValue(AppName) + LineEnding +
      'Comment=' + SafeDesktopValue(EdDescription.Text) + LineEnding +
      'Exec=/usr/bin/' + PackageName + LineEnding +
      'Terminal=' + LowerCase(BoolToStr(ChkTerminal.Checked, True)) + LineEnding +
      'Categories=' + EdCategory.Text + ';' + LineEnding;
    if IconPath <> '' then
    begin
      IconExt := LowerCase(ExtractFileExt(IconPath));
      if not ((IconExt = '.png') or (IconExt = '.svg') or (IconExt = '.xpm')) then
        raise Exception.Create('Als Symbol bitte PNG, SVG oder XPM verwenden.');
      if not ForceDirectories(IconDir) then
        raise Exception.Create('Symbolordner konnte nicht angelegt werden.');
      CopyFileStream(IconPath, IconDir + '/' + PackageName + IconExt);
      DesktopText := DesktopText + 'Icon=' + PackageName + LineEnding;
    end;
    DesktopFile := DesktopDir + '/' + PackageName + '.desktop';
    WriteUTF8File(DesktopFile, DesktopText);

    ControlText := 'Package: ' + PackageName + LineEnding +
      'Version: ' + VersionStr + LineEnding +
      'Section: utils' + LineEnding +
      'Priority: optional' + LineEnding +
      'Architecture: ' + Arch + LineEnding +
      'Maintainer: ' + EdMaintainer.Text + LineEnding +
      'Description: ' + EdDescription.Text + LineEnding;
    WriteUTF8File(DataDir + '/control', ControlText);

    Log('Erzeuge: ' + TargetDeb);
    Application.ProcessMessages;
    P := TProcess.Create(nil);
    try
      P.Executable := 'dpkg-deb';
      P.Parameters.Add('--build');
      P.Parameters.Add('--root-owner-group');
      P.Parameters.Add(RootDir);
      P.Parameters.Add(TargetDeb);
      P.Options := [poWaitOnExit, poUsePipes, poStderrToOutPut];
      P.Execute;
      ExitValue := P.ExitStatus;
      SL := TStringList.Create;
      try
        SL.LoadFromStream(P.Output);
        OutputMsg := Trim(SL.Text);
      finally
        SL.Free;
      end;
      if OutputMsg <> '' then Log(OutputMsg);
      if ExitValue <> 0 then raise Exception.Create('dpkg-deb meldet Fehlercode ' + IntToStr(ExitValue));
    finally
      P.Free;
    end;
    FLastDeb := TargetDeb;
    Log('FERTIG: ' + TargetDeb);
    MessageDlg('Erfolgreich', 'Das Installationspaket wurde erstellt:' +
      LineEnding + TargetDeb, mtInformation, [mbOK], 0);
  finally
    { Nur unseren temporären Ordner entfernen, niemals das Zielpaket. }
    if DirectoryExists(RootDir) then DeleteDirectory(RootDir, False);
  end;
end;

function TMainForm.SafeFilePart(const Value: string): string;
var
  I: Integer;
begin
  Result := Value;
  for I := 1 to Length(Result) do
    if not (Result[I] in ['a'..'z','A'..'Z','0'..'9','-','_','.']) then
      Result[I] := '_';
end;

function TMainForm.DebSHA256(const DebFile: string): string;
var
  P: TProcess;
  SL: TStringList;
begin
  if FindDefaultExecutablePath('sha256sum') = '' then
    raise Exception.Create('sha256sum fehlt (Paket coreutils).');
  P := TProcess.Create(nil);
  SL := TStringList.Create;
  try
    P.Executable := 'sha256sum';
    P.Parameters.Add('--');
    P.Parameters.Add(DebFile);
    P.Options := [poWaitOnExit, poUsePipes, poStderrToOutPut];
    P.Execute;
    SL.LoadFromStream(P.Output);
    if (P.ExitStatus <> 0) or (Length(Trim(SL.Text)) < 64) then
      raise Exception.Create('SHA256-Prüfsumme konnte nicht berechnet werden: ' + Trim(SL.Text));
    Result := Copy(Trim(SL.Text), 1, 64);
  finally
    SL.Free;
    P.Free;
  end;
end;

procedure TMainForm.CopyStreamToEnd(const ASource, ADest: string);
var
  SourceStream, TargetStream: TFileStream;
begin
  SourceStream := TFileStream.Create(ASource, fmOpenRead or fmShareDenyWrite);
  try
    TargetStream := TFileStream.Create(ADest, fmOpenWrite or fmShareDenyWrite);
    try
      TargetStream.Position := TargetStream.Size;
      TargetStream.CopyFrom(SourceStream, 0);
    finally
      TargetStream.Free;
    end;
  finally
    SourceStream.Free;
  end;
end;

function TMainForm.BuildRun(const DebFile: string): string;
var
  OutputDir, OutputRun, TempRun, Hash, Header, BaseName: string;
begin
  Result := '';
  if not FileExists(DebFile) then
    raise Exception.Create('Bitte eine vorhandene DEB-Datei auswählen.');
  if ExtractFileExt(LowerCase(DebFile)) <> '.deb' then
    raise Exception.Create('Die ausgewählte Datei muss die Endung .deb besitzen.');
  OutputDir := Trim(EdOutput.Text);
  if not DirectoryExists(OutputDir) then
    raise Exception.Create('Der Ausgabeordner existiert nicht.');
  BaseName := SafeFilePart(ChangeFileExt(ExtractFileName(DebFile), ''));
  OutputRun := IncludeTrailingPathDelimiter(OutputDir) + BaseName + '-Setup.run';
  if ExpandFileName(DebFile) = ExpandFileName(OutputRun) then
    raise Exception.Create('Eingabedatei und Ausgabe dürfen nicht identisch sein.');
  if FileExists(OutputRun) and
     (MessageDlg('Datei überschreiben?', 'Die RUN-Datei existiert bereits. Überschreiben?',
       mtConfirmation, [mbYes,mbNo], 0) <> mrYes) then Exit;
  Hash := DebSHA256(DebFile);
  Header := '#!/bin/sh' + #10 +
    '# OpenLazarusSetup 1.2 - selbstinstallierendes Debian-Paket' + #10 +
    'set -eu' + #10 +
    'export LC_ALL=C' + #10 +
    'if ! command -v apt-get >/dev/null 2>&1; then' + #10 +
    '  echo "Dieses Setup benötigt Debian/Ubuntu mit apt-get." >&2; exit 1' + #10 +
    'fi' + #10 +
    'if ! command -v sha256sum >/dev/null 2>&1; then' + #10 +
    '  echo "sha256sum fehlt." >&2; exit 1' + #10 +
    'fi' + #10 +
    'confirm_install() {' + #10 +
    '  if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && command -v kdialog >/dev/null 2>&1; then' + #10 +
    '    kdialog --title "OpenLazarusSetup" --yesno "Das eingebettete DEB-Paket installieren? Administratorrechte sind erforderlich."' + #10 +
    '  elif [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && command -v zenity >/dev/null 2>&1; then' + #10 +
    '    zenity --question --title="OpenLazarusSetup" --text="Das eingebettete DEB-Paket installieren? Administratorrechte sind erforderlich."' + #10 +
    '  elif [ -t 0 ]; then' + #10 +
    '    printf "DEB-Paket installieren? [j/N] "' + #10 +
    '    read answer || return 1' + #10 +
    '    case "$answer" in j|J|ja|Ja|JA|y|Y|yes|YES) return 0 ;; *) return 1 ;; esac' + #10 +
    '  else' + #10 +
    '    echo "Keine grafische Bestätigung und kein Terminal verfügbar." >&2; return 1' + #10 +
    '  fi' + #10 +
    '}' + #10 +
    'if ! confirm_install; then echo "Installation abgebrochen."; exit 1; fi' + #10 +
    'tmpdir=$(mktemp -d "${TMPDIR:-/tmp}/ols-run.XXXXXXXX") || exit 1' + #10 +
    'trap ''rm -rf -- "$tmpdir"'' EXIT HUP INT TERM' + #10 +
    'chmod 700 "$tmpdir"' + #10 +
    'payload_line=$(awk ''/^__OLS_DEB_PAYLOAD__$/ { print NR + 1; exit }'' "$0")' + #10 +
    'if [ -z "$payload_line" ]; then echo "Paketdaten fehlen." >&2; exit 1; fi' + #10 +
    'tail -n +"$payload_line" "$0" > "$tmpdir/package.deb"' + #10 +
    'actual=$(sha256sum "$tmpdir/package.deb")' + #10 +
    'actual=${actual%% *}' + #10 +
    'if [ "$actual" != "' + Hash + '" ]; then' + #10 +
    '  echo "FEHLER: Prüfsumme stimmt nicht. Installation verweigert." >&2; exit 1' + #10 +
    'fi' + #10 +
    'echo "Prüfsumme OK. Starte Paketinstallation..."' + #10 +
    'if [ "$(id -u)" -eq 0 ]; then' + #10 +
    '  apt-get install -- "$tmpdir/package.deb"' + #10 +
    'elif [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && command -v pkexec >/dev/null 2>&1; then' + #10 +
    '  pkexec /usr/bin/apt-get install -- "$tmpdir/package.deb"' + #10 +
    'elif [ -t 0 ] && command -v sudo >/dev/null 2>&1; then' + #10 +
    '  sudo apt-get install -- "$tmpdir/package.deb"' + #10 +
    'else' + #10 +
    '  echo "Keine Passwortabfrage verfügbar. Bitte die RUN-Datei im Terminal starten." >&2; exit 1' + #10 +
    'fi' + #10 +
    'echo "Paketinstallation abgeschlossen."' + #10 +
    'exit 0' + #10 +
    '__OLS_DEB_PAYLOAD__' + #10;
  TempRun := OutputRun + '.creating-' + IntToStr(fpGetpid);
  if FileExists(TempRun) then DeleteFile(TempRun);
  try
    WriteUTF8File(TempRun, Header);
    CopyStreamToEnd(DebFile, TempRun);
    if fpChmod(PChar(TempRun), &755) <> 0 then
      raise Exception.Create('RUN-Datei konnte nicht ausführbar gemacht werden.');
    if FileExists(OutputRun) and not DeleteFile(OutputRun) then
      raise Exception.Create('Alte RUN-Datei konnte nicht entfernt werden.');
    if not RenameFile(TempRun, OutputRun) then
      raise Exception.Create('RUN-Datei konnte nicht ins Ausgabeziel verschoben werden.');
    Result := OutputRun;
    EdRunFile.Text := OutputRun;
    Log('RUN erstellt: ' + OutputRun);
    Log('SHA256 (DEB): ' + Hash);
    MessageDlg('RUN erstellt', 'Die selbstinstallierende Datei wurde erstellt:' +
      LineEnding + OutputRun + LineEnding + LineEnding +
      'Zum Starten: ' + './' + ExtractFileName(OutputRun), mtInformation, [mbOK], 0);
  finally
    if FileExists(TempRun) then DeleteFile(TempRun);
  end;
end;


procedure TMainForm.BuildZip(const RunFile: string);
var
  OutputDir, ZipFile, TempZip, WorkDir, RunName, ReadmeFile: string;
  P: TProcess;
  SL: TStringList;
  OutputText: string;
begin
  if (not FileExists(RunFile)) or
     (LowerCase(ExtractFileExt(RunFile)) <> '.run') then
    raise Exception.Create('Bitte eine vorhandene .run-Datei auswählen.');
  if FindDefaultExecutablePath('zip') = '' then
    raise Exception.Create('Das Werkzeug zip fehlt. Installation: sudo apt install zip');
  OutputDir := ExpandFileName(Trim(EdOutput.Text));
  if not DirectoryExists(OutputDir) then
    raise Exception.Create('Der Ausgabeordner existiert nicht.');
  RunName := ExtractFileName(RunFile);
  ZipFile := IncludeTrailingPathDelimiter(OutputDir) +
    SafeFilePart(ChangeFileExt(RunName, '')) + '.zip';
  if FileExists(ZipFile) and
    (MessageDlg('Datei überschreiben?',
      'Die ZIP-Datei existiert bereits. Überschreiben?',
      mtConfirmation, [mbYes, mbNo], 0) <> mrYes) then Exit;

  WorkDir := IncludeTrailingPathDelimiter(GetTempDir(False)) +
    'ols-zip-' + IntToStr(fpGetpid) + '-' +
    FormatDateTime('yyyymmddhhnnsszzz', Now);
  if not ForceDirectories(WorkDir) then
    raise Exception.Create('ZIP-Arbeitsordner konnte nicht angelegt werden.');
  TempZip := ZipFile + '.creating-' + IntToStr(fpGetpid);
  try
    CopyFileStream(RunFile, WorkDir + '/' + RunName);
    if fpChmod(PChar(WorkDir + '/' + RunName), &755) <> 0 then
      raise Exception.Create('RUN-Datei im ZIP-Arbeitsordner nicht ausführbar.');
    ReadmeFile := WorkDir + '/INSTALLATION.txt';
    WriteUTF8File(ReadmeFile,
      'OpenLazarusSetup 1.2 - Installationsanleitung' + LineEnding +
      '=================================================' + LineEnding + LineEnding +
      '1. ZIP-Datei entpacken.' + LineEnding +
      '2. Terminal im entpackten Ordner öffnen.' + LineEnding +
      '3. Ausführungsrecht setzen:' + LineEnding +
      '   chmod +x -- ./' + RunName + LineEnding +
      '4. Installationsprogramm starten:' + LineEnding +
      '   ./' + RunName + LineEnding + LineEnding +
      'Vor der Installation fragt das Setup nach Ihrer Zustimmung.' + LineEnding +
      'Für die eigentliche Paketinstallation sind Administratorrechte nötig.' + LineEnding +
      'Bitte nur Dateien aus vertrauenswürdigen Quellen ausführen.' + LineEnding +
      'Benötigte Paketabhängigkeiten müssen aus den eingerichteten' + LineEnding +
      'Paketquellen verfügbar sein.' + LineEnding);
    if FileExists(TempZip) then
      if not DeleteFile(TempZip) then
        raise Exception.Create('Alte temporäre ZIP-Datei kann nicht gelöscht werden.');

    P := TProcess.Create(nil);
    SL := TStringList.Create;
    try
      P.Executable := 'zip';
      P.CurrentDirectory := WorkDir;
      P.Parameters.Add('-q');
      P.Parameters.Add('-X');
      P.Parameters.Add(TempZip);
      P.Parameters.Add('--');
      P.Parameters.Add(RunName);
      P.Parameters.Add('INSTALLATION.txt');
      P.Options := [poWaitOnExit, poUsePipes, poStderrToOutPut];
      P.Execute;
      SL.LoadFromStream(P.Output);
      OutputText := Trim(SL.Text);
      if P.ExitStatus <> 0 then
        raise Exception.Create('zip meldet Fehler ' + IntToStr(P.ExitStatus) +
          ': ' + OutputText);
    finally
      SL.Free;
      P.Free;
    end;
    if not FileExists(TempZip) then
      raise Exception.Create('ZIP-Datei wurde nicht erzeugt.');
    if FileExists(ZipFile) and not DeleteFile(ZipFile) then
      raise Exception.Create('Vorhandene ZIP-Datei kann nicht überschrieben werden.');
    if not RenameFile(TempZip, ZipFile) then
      raise Exception.Create('ZIP-Datei kann nicht an den Zielort verschoben werden.');
    Log('ZIP erstellt: ' + ZipFile);
    MessageDlg('ZIP erstellt',
      'Das Archiv für die Veröffentlichung wurde erstellt:' +
      LineEnding + ZipFile + LineEnding + LineEnding +
      'Enthält RUN-Datei und INSTALLATION.txt.',
      mtInformation, [mbOK], 0);
  finally
    if FileExists(TempZip) then DeleteFile(TempZip);
    if DirectoryExists(WorkDir) then DeleteDirectory(WorkDir, False);
  end;
end;

end.
