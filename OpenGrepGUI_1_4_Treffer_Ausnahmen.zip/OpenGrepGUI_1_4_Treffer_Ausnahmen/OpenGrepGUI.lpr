program OpenGrepGUI;

{$mode objfpc}{$H+}

uses
  Interfaces, Forms, MainUnit;

{$R *.res}

begin
  RequireDerivedFormResource := True;
  Application.Scaled := True;
  Application.Initialize;
  Application.Title := 'OpenGrepGUI 1.0';
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
