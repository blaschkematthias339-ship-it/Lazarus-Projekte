unit MainUnit;

{$mode objfpc}{$H+}
{$codepage utf8}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls,
  ExtCtrls, Grids, Process, pipes, fpjson, jsonparser, LCLIntf;

type
  TSearchHit = record
    FileName: string;
    LineNumber: Integer;
    ColumnNumber: Integer;
    MatchedLine: string;
  end;

  TMainForm = class(TForm)
    BtnAddException: TButton;
    BtnReplace: TButton;
    CheckSingleFile: TCheckBox;
    CheckExceptions: TCheckBox;
    MemoExceptions: TMemo;
    PanelExceptions: TPanel;
    LabelExceptions: TLabel;
    EditReplace: TEdit;
    LabelReplace: TLabel;
    BtnBrowse: TButton;
    BtnOpen: TButton;
    BtnSearch: TButton;
    BtnStop: TButton;
    CheckCase: TCheckBox;
    CheckHidden: TCheckBox;
    CheckRegex: TCheckBox;
    CheckSubdirs: TCheckBox;
    CheckWholeWord: TCheckBox;
    EditFolder: TEdit;
    EditMask: TEdit;
    EditSearch: TEdit;
    GridResults: TStringGrid;
    LabelFolder: TLabel;
    LabelMask: TLabel;
    LabelPreview: TLabel;
    LabelSearch: TLabel;
    MemoPreview: TMemo;
    PanelBottom: TPanel;
    PanelOptions: TPanel;
    PanelPreview: TPanel;
    PanelTop: TPanel;
    StatusLabel: TLabel;
    TimerPoll: TTimer;
    procedure BtnAddExceptionClick(Sender: TObject);
    procedure BtnReplaceClick(Sender: TObject);
    procedure BtnBrowseClick(Sender: TObject);
    procedure CheckSingleFileChange(Sender: TObject);
    procedure BtnOpenClick(Sender: TObject);
    procedure BtnSearchClick(Sender: TObject);
    procedure BtnStopClick(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure GridResultsDblClick(Sender: TObject);
    procedure GridResultsSelectCell(Sender: TObject; aCol, aRow: Integer;
      var CanSelect: Boolean);
    procedure TimerPollTimer(Sender: TObject);
  private
    FProcess: TProcess;
    FOutBuffer: RawByteString;
    FErrBuffer: RawByteString;
    FErrText: string;
    FHits: array of TSearchHit;
    FHitCount: Integer;
    FTruncated: Boolean;
    FStopping: Boolean;
    FSearchCompleted: Boolean;
    FLastSearchText: string;
    FLastTarget: string;
    FLastSingleFile: Boolean;
    FLastMask: string;
    FLastSubdirs, FLastHidden: Boolean;
    FLastCase, FLastRegex, FLastWholeWord: Boolean;
    function ExceptionConfigFile: string;
    procedure LoadExceptions;
    procedure SaveExceptions;
    procedure SetSearching(const ASearching: Boolean);
    procedure AddHit(const AHit: TSearchHit);
    procedure ProcessOutputLine(const ALine: string);
    procedure ConsumeBuffer(var ABuffer: RawByteString; const AChunk: RawByteString;
      const AIsError: Boolean);
    procedure DrainPipe(const APipe: TInputPipeStream;
      var ABuffer: RawByteString; const AIsError: Boolean);
    procedure FinishSearch;
    procedure StopSearch;
    procedure ShowPreview(const AIndex: Integer);
    function CurrentHitIndex: Integer;
    function PrepareReplacement(const AFile, ASearch, AReplace: string;
      out AOriginal, AChanged: RawByteString; out ACount, ASkipped: Integer): Boolean;
    procedure SaveReplacement(const AFile: string;
      const AOriginal, AChanged: RawByteString);
  end;

var
  MainForm: TMainForm;

implementation

{$R *.lfm}

const
  MAX_DISPLAY_HITS = 20000;
  MAX_PENDING_BYTES = 2 * 1024 * 1024;
  MAX_REPLACE_FILE_BYTES = 16 * 1024 * 1024;

function JsonString(const ARoot: TJSONData; const APath: string): string;
var
  Value: TJSONData;
begin
  Result := '';
  if ARoot = nil then Exit;
  Value := ARoot.FindPath(APath);
  if (Value <> nil) and (Value.JSONType = jtString) then
    Result := Value.AsString;
end;

function JsonInteger(const ARoot: TJSONData; const APath: string): Integer;
var
  Value: TJSONData;
begin
  Result := 0;
  if ARoot = nil then Exit;
  Value := ARoot.FindPath(APath);
  if (Value <> nil) and (Value.JSONType = jtNumber) then
    Result := Value.AsInteger;
end;

function TMainForm.ExceptionConfigFile: string;
begin
  Result := GetAppConfigDir(False) + 'OpenGrepGUI_Ausnahmen.txt';
end;

procedure TMainForm.LoadExceptions;
var
  L: TStringList;
begin
  CheckExceptions.Checked := False;
  L := TStringList.Create;
  try
    try
      if FileExists(ExceptionConfigFile) then
      begin
        L.LoadFromFile(ExceptionConfigFile);
        if L.Count > 0 then
        begin
          CheckExceptions.Checked := L[0] = 'aktiv=1';
          L.Delete(0);
        end;
        MemoExceptions.Lines.Assign(L);
      end;
    except
      on E: Exception do
        StatusLabel.Caption := 'Ausnahmeliste konnte nicht geladen werden: ' + E.Message;
    end;
  finally
    L.Free;
  end;
end;

procedure TMainForm.SaveExceptions;
var
  L: TStringList;
  Dir: string;
begin
  L := TStringList.Create;
  try
    if CheckExceptions.Checked then L.Add('aktiv=1')
    else L.Add('aktiv=0');
    L.AddStrings(MemoExceptions.Lines);
    try
      Dir := ExtractFileDir(ExceptionConfigFile);
      if ForceDirectories(Dir) then
        L.SaveToFile(ExceptionConfigFile);
    except
      // Fehler beim Speichern dürfen das Beenden nicht verhindern.
    end;
  finally
    L.Free;
  end;
end;

procedure TMainForm.FormCreate(Sender: TObject);
begin
  Caption := 'OpenGrepGUI 1.4 – Treffer in Ausnahmeliste übernehmen';
  EditFolder.Text := GetUserDir;
  CheckSingleFile.Checked := False;
  CheckSingleFileChange(nil);
  EditMask.Text := '';
  CheckSubdirs.Checked := True;
  CheckRegex.Checked := False;
  CheckHidden.Checked := False;
  CheckCase.Checked := False;
  CheckWholeWord.Checked := False;

  GridResults.FixedCols := 0;
  GridResults.ColCount := 4;
  GridResults.RowCount := 2;
  GridResults.FixedRows := 1;
  GridResults.Options := GridResults.Options + [goRowSelect, goColSizing] - [goEditing];
  GridResults.Cells[0, 0] := 'Datei';
  GridResults.Cells[1, 0] := 'Zeile';
  GridResults.Cells[2, 0] := 'Spalte';
  GridResults.Cells[3, 0] := 'Gefundener Text';
  GridResults.ColWidths[0] := 255;
  GridResults.ColWidths[1] := 65;
  GridResults.ColWidths[2] := 65;
  GridResults.ColWidths[3] := 570;
  GridResults.Cells[0, 1] := '';
  GridResults.Cells[1, 1] := '';
  GridResults.Cells[2, 1] := '';
  GridResults.Cells[3, 1] := '';

  TimerPoll.Enabled := False;
  TimerPoll.Interval := 60;
  MemoPreview.Clear;
  FProcess := nil;
  FHitCount := 0;
  FSearchCompleted := False;
  FLastSearchText := '';
  FLastTarget := '';
  LoadExceptions;
  SetSearching(False);
  StatusLabel.Caption := 'Bereit. Suchbegriff eingeben und Suchen drücken.';
end;

procedure TMainForm.FormDestroy(Sender: TObject);
begin
  SaveExceptions;
  TimerPoll.Enabled := False;
  if FProcess <> nil then
  begin
    if FProcess.Running then FProcess.Terminate(0);
    FreeAndNil(FProcess);
  end;
end;

procedure TMainForm.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  CanClose := True;
  if (FProcess <> nil) and FProcess.Running then
  begin
    CanClose := MessageDlg('Suche läuft',
      'Die laufende Suche beenden und das Programm schließen?',
      mtConfirmation, [mbYes, mbNo], 0) = mrYes;
    if CanClose then StopSearch;
  end;
end;

procedure TMainForm.SetSearching(const ASearching: Boolean);
begin
  BtnSearch.Enabled := not ASearching;
  BtnStop.Enabled := ASearching;
  BtnReplace.Enabled := not ASearching;
  EditReplace.Enabled := not ASearching;
  EditSearch.Enabled := not ASearching;
  EditFolder.Enabled := not ASearching;
  BtnBrowse.Enabled := not ASearching;
  CheckSingleFile.Enabled := not ASearching;
  EditMask.Enabled := (not ASearching) and (not CheckSingleFile.Checked);
  CheckSubdirs.Enabled := (not ASearching) and (not CheckSingleFile.Checked);
  CheckHidden.Enabled := (not ASearching) and (not CheckSingleFile.Checked);
  CheckRegex.Enabled := not ASearching;
  CheckCase.Enabled := not ASearching;
  CheckWholeWord.Enabled := not ASearching;
  CheckExceptions.Enabled := not ASearching;
  MemoExceptions.Enabled := not ASearching;
  BtnAddException.Enabled := not ASearching;
end;

procedure TMainForm.CheckSingleFileChange(Sender: TObject);
begin
  if CheckSingleFile.Checked then
  begin
    LabelFolder.Caption := 'Einzeldatei';
    BtnBrowse.Caption := 'Datei wählen';
    EditFolder.Text := '';
    EditMask.Enabled := False;
    CheckSubdirs.Enabled := False;
    CheckHidden.Enabled := False;
    LabelMask.Enabled := False;
  end
  else
  begin
    LabelFolder.Caption := 'Suchordner';
    BtnBrowse.Caption := 'Ordner wählen';
    EditFolder.Text := GetUserDir;
    EditMask.Enabled := True;
    CheckSubdirs.Enabled := True;
    CheckHidden.Enabled := True;
    LabelMask.Enabled := True;
  end;
  FSearchCompleted := False;
  if StatusLabel <> nil then
    StatusLabel.Caption := 'Suchbereich geändert. Bitte erneut suchen.';
end;

procedure TMainForm.BtnBrowseClick(Sender: TObject);
var
  D: TSelectDirectoryDialog;
  F: TOpenDialog;
begin
  if CheckSingleFile.Checked then
  begin
    F := TOpenDialog.Create(Self);
    try
      F.Title := 'Eine Datei zum Suchen und Ersetzen auswählen';
      F.Options := F.Options + [ofFileMustExist, ofPathMustExist];
      if FileExists(EditFolder.Text) then
        F.FileName := EditFolder.Text
      else
        F.InitialDir := GetUserDir;
      if F.Execute then EditFolder.Text := F.FileName;
    finally
      F.Free;
    end;
  end
  else
  begin
    D := TSelectDirectoryDialog.Create(Self);
    try
      D.Title := 'Ordner für die Suche auswählen';
      D.FileName := EditFolder.Text;
      if D.Execute then EditFolder.Text := D.FileName;
    finally
      D.Free;
    end;
  end;
end;

procedure TMainForm.BtnSearchClick(Sender: TObject);
var
  Folder, Mask: string;
begin
  if FProcess <> nil then Exit;
  if Trim(EditSearch.Text) = '' then
  begin
    MessageDlg('Hinweis', 'Bitte einen Suchbegriff eingeben.', mtInformation, [mbOK], 0);
    EditSearch.SetFocus;
    Exit;
  end;

  Folder := ExpandFileName(Trim(EditFolder.Text));
  if CheckSingleFile.Checked then
  begin
    if not FileExists(Folder) then
    begin
      MessageDlg('Fehler', 'Bitte eine vorhandene Einzeldatei auswählen.', mtError, [mbOK], 0);
      Exit;
    end;
  end
  else if not DirectoryExists(Folder) then
  begin
    MessageDlg('Fehler', 'Der gewählte Suchordner existiert nicht.', mtError, [mbOK], 0);
    Exit;
  end;

  FHitCount := 0;
  FSearchCompleted := False;
  FLastSearchText := EditSearch.Text;
  FLastTarget := Folder;
  FLastSingleFile := CheckSingleFile.Checked;
  FLastMask := Trim(EditMask.Text);
  FLastSubdirs := CheckSubdirs.Checked;
  FLastHidden := CheckHidden.Checked;
  FLastCase := CheckCase.Checked;
  FLastRegex := CheckRegex.Checked;
  FLastWholeWord := CheckWholeWord.Checked;
  SetLength(FHits, 0);
  FOutBuffer := '';
  FErrBuffer := '';
  FErrText := '';
  FTruncated := False;
  FStopping := False;
  GridResults.RowCount := 2;
  GridResults.Cells[0, 0] := 'Datei';
  GridResults.Cells[1, 0] := 'Zeile';
  GridResults.Cells[2, 0] := 'Spalte';
  GridResults.Cells[3, 0] := 'Gefundener Text';
  MemoPreview.Clear;

  FProcess := TProcess.Create(nil);
  try
    FProcess.Executable := 'rg';
    FProcess.Options := [poUsePipes, poNoConsole];
    FProcess.Parameters.Add('--json');
    FProcess.Parameters.Add('--color=never');
    if not CheckRegex.Checked then FProcess.Parameters.Add('--fixed-strings');
    if not CheckCase.Checked then FProcess.Parameters.Add('--ignore-case');
    if CheckWholeWord.Checked then FProcess.Parameters.Add('--word-regexp');
    if CheckHidden.Checked and (not CheckSingleFile.Checked) then FProcess.Parameters.Add('--hidden');
    if not CheckSubdirs.Checked and (not CheckSingleFile.Checked) then FProcess.Parameters.Add('--max-depth=1');
    Mask := Trim(EditMask.Text);
    if (Mask <> '') and (not CheckSingleFile.Checked) then
    begin
      FProcess.Parameters.Add('--glob');
      FProcess.Parameters.Add(Mask);
    end;
    // Wichtig: Suchbegriff und Pfad sind eigene Argumente, kein Shell-Aufruf.
    FProcess.Parameters.Add('--');
    FProcess.Parameters.Add(EditSearch.Text);
    FProcess.Parameters.Add(Folder);
    FProcess.Execute;
  except
    on E: Exception do
    begin
      FreeAndNil(FProcess);
      MessageDlg('ripgrep konnte nicht gestartet werden',
        E.Message + LineEnding + LineEnding +
        'Bitte ripgrep installieren: sudo apt install ripgrep',
        mtError, [mbOK], 0);
      Exit;
    end;
  end;
  SetSearching(True);
  StatusLabel.Caption := 'Suche läuft …';
  TimerPoll.Enabled := True;
end;

procedure TMainForm.StopSearch;
begin
  if FProcess = nil then Exit;
  FStopping := True;
  if FProcess.Running then FProcess.Terminate(0);
  StatusLabel.Caption := 'Suche wird beendet …';
end;

procedure TMainForm.BtnStopClick(Sender: TObject);
begin
  StopSearch;
end;

procedure TMainForm.AddHit(const AHit: TSearchHit);
var
  R: Integer;
begin
  if FHitCount >= MAX_DISPLAY_HITS then
  begin
    if not FTruncated then
    begin
      FTruncated := True;
      StopSearch;
    end;
    Exit;
  end;
  if FHitCount >= Length(FHits) then
    SetLength(FHits, FHitCount + 512);
  FHits[FHitCount] := AHit;
  Inc(FHitCount);
  R := FHitCount;
  if GridResults.RowCount <= R then GridResults.RowCount := R + 1;
  GridResults.Cells[0, R] := AHit.FileName;
  GridResults.Cells[1, R] := IntToStr(AHit.LineNumber);
  GridResults.Cells[2, R] := IntToStr(AHit.ColumnNumber);
  GridResults.Cells[3, R] := AHit.MatchedLine;
  if (FHitCount mod 25 = 0) then
    StatusLabel.Caption := Format('Suche läuft … %d Treffer', [FHitCount]);
end;

procedure TMainForm.ProcessOutputLine(const ALine: string);
var
  Root: TJSONData;
  Hit: TSearchHit;
  S: string;
begin
  if ALine = '' then Exit;
  Root := nil;
  try
    Root := GetJSON(ALine);
    if JsonString(Root, 'type') = 'match' then
    begin
    Hit.FileName := JsonString(Root, 'data.path.text');
    Hit.LineNumber := JsonInteger(Root, 'data.line_number');
    Hit.ColumnNumber := 0;
    if Root.FindPath('data.submatches[0].start') <> nil then
      Hit.ColumnNumber := JsonInteger(Root, 'data.submatches[0].start') + 1;
    Hit.MatchedLine := JsonString(Root, 'data.lines.text');
    S := Hit.MatchedLine;
    while (Length(S) > 0) and (S[Length(S)] in [#10, #13]) do
      Delete(S, Length(S), 1);
    Hit.MatchedLine := S;
    if Hit.FileName <> '' then AddHit(Hit);
    end;
  except
    on E: Exception do
      // Einzelne ungültige JSON-Zeilen sollen nicht die gesamte Suche abbrechen.
      FErrText := 'Ein Suchergebnis konnte nicht gelesen werden: ' + E.Message;
  end;
  Root.Free;
end;

procedure TMainForm.ConsumeBuffer(var ABuffer: RawByteString;
  const AChunk: RawByteString; const AIsError: Boolean);
var
  P: SizeInt;
  Line: RawByteString;
begin
  ABuffer := ABuffer + AChunk;
  repeat
    P := Pos(#10, ABuffer);
    if P = 0 then Break;
    Line := Copy(ABuffer, 1, P - 1);
    Delete(ABuffer, 1, P);
    if AIsError then
    begin
      if Length(FErrText) < 4000 then
        FErrText := FErrText + string(Line) + LineEnding;
    end
    else
      ProcessOutputLine(string(Line));
  until False;
  if Length(ABuffer) > MAX_PENDING_BYTES then
  begin
    if AIsError then FErrText := FErrText + 'Fehlerausgabe zu lang.'
    else FErrText := FErrText + 'Eine Ergebniszeile war zu lang.';
    ABuffer := '';
  end;
end;

procedure TMainForm.DrainPipe(const APipe: TInputPipeStream;
  var ABuffer: RawByteString; const AIsError: Boolean);
var
  Available, Count, Iteration: Integer;
  Chunk: RawByteString;
begin
  if APipe = nil then Exit;
  Iteration := 0;
  while (APipe.NumBytesAvailable > 0) and (Iteration < 16) do
  begin
    Available := APipe.NumBytesAvailable;
    Count := Available;
    if Count > 8192 then Count := 8192;
    if Count < 1 then Break;
    SetLength(Chunk, Count);
    Count := APipe.Read(Chunk[1], Count);
    if Count <= 0 then Break;
    SetLength(Chunk, Count);
    ConsumeBuffer(ABuffer, Chunk, AIsError);
    Inc(Iteration);
  end;
end;

procedure TMainForm.TimerPollTimer(Sender: TObject);
begin
  if FProcess = nil then Exit;
  DrainPipe(FProcess.Output, FOutBuffer, False);
  DrainPipe(FProcess.Stderr, FErrBuffer, True);
  if not FProcess.Running then
  begin
    if (FProcess.Output.NumBytesAvailable = 0) and
       (FProcess.Stderr.NumBytesAvailable = 0) then
      FinishSearch;
  end;
end;

procedure TMainForm.FinishSearch;
var
  ExitCode: Integer;
begin
  TimerPoll.Enabled := False;
  if FOutBuffer <> '' then
    ProcessOutputLine(string(FOutBuffer));
  if FErrBuffer <> '' then
    FErrText := FErrText + string(FErrBuffer);
  FOutBuffer := '';
  FErrBuffer := '';
  ExitCode := FProcess.ExitStatus;
  FreeAndNil(FProcess);
  FSearchCompleted := (not FStopping) and (not FTruncated) and (ExitCode <= 1) and (Trim(FErrText) = '');
  SetSearching(False);
  if FTruncated then
    StatusLabel.Caption := Format('Anzeige bei %d Treffern begrenzt.', [FHitCount])
  else if FStopping then
    StatusLabel.Caption := Format('Abgebrochen – %d Treffer gefunden.', [FHitCount])
  else if (ExitCode = 0) or (ExitCode = 1) then
    StatusLabel.Caption := Format('Fertig – %d Treffer gefunden.', [FHitCount])
  else
    StatusLabel.Caption := Format('Suchfehler (Code %d) – %s', [ExitCode, Trim(FErrText)]);
  if (ExitCode > 1) and not FStopping then
    MessageDlg('Suchfehler', 'ripgrep meldet: ' + Trim(FErrText), mtWarning, [mbOK], 0);
end;

function TMainForm.CurrentHitIndex: Integer;
begin
  Result := GridResults.Row - 1;
  if (Result < 0) or (Result >= FHitCount) then Result := -1;
end;

procedure TMainForm.ShowPreview(const AIndex: Integer);
var
  Hit: TSearchHit;
  Lines: TStringList;
  F: TFileStream;
  I, Lo, Hi: Integer;
  Prefix: string;
begin
  MemoPreview.Clear;
  if (AIndex < 0) or (AIndex >= FHitCount) then Exit;
  Hit := FHits[AIndex];
  MemoPreview.Lines.Add(Hit.FileName);
  MemoPreview.Lines.Add(Format('Zeile %d, Spalte %d',
    [Hit.LineNumber, Hit.ColumnNumber]));
  MemoPreview.Lines.Add('');
  if not FileExists(Hit.FileName) then
  begin
    MemoPreview.Lines.Add(Hit.MatchedLine);
    Exit;
  end;
  // Große Dateien nicht vollständig in den Speicher laden.
  try
    F := TFileStream.Create(Hit.FileName, fmOpenRead or fmShareDenyNone);
    try
      if F.Size > 2 * 1024 * 1024 then
      begin
        MemoPreview.Lines.Add(Hit.MatchedLine);
        MemoPreview.Lines.Add('');
        MemoPreview.Lines.Add('(Kontextansicht für Dateien über 2 MB deaktiviert.)');
        Exit;
      end;
    finally
      F.Free;
    end;
  except
    on E: Exception do
    begin
      MemoPreview.Lines.Add(Hit.MatchedLine);
      MemoPreview.Lines.Add('Vorschau nicht lesbar: ' + E.Message);
      Exit;
    end;
  end;
  Lines := TStringList.Create;
  try
    try
      Lines.LoadFromFile(Hit.FileName);
      Lo := Hit.LineNumber - 4;
      if Lo < 1 then Lo := 1;
      Hi := Hit.LineNumber + 4;
      if Hi > Lines.Count then Hi := Lines.Count;
      for I := Lo to Hi do
      begin
        if I = Hit.LineNumber then Prefix := '> '
        else Prefix := '  ';
        MemoPreview.Lines.Add(Prefix + Format('%5d  ', [I]) + Lines[I - 1]);
      end;
    except
      on E: Exception do
        MemoPreview.Lines.Add('Vorschau nicht verfügbar: ' + E.Message);
    end;
  finally
    Lines.Free;
  end;
end;

procedure TMainForm.GridResultsSelectCell(Sender: TObject; aCol,
  aRow: Integer; var CanSelect: Boolean);
begin
  if (aRow > 0) and (aRow <= FHitCount) then
    ShowPreview(aRow - 1);
end;

// Die vollständige Fundzeile wird als geschützte Textfolge übernommen.
// Dadurch bleibt das eigentliche Suchergebnis unverändert und der Benutzer
// kann die Ausnahme bei Bedarf im Memo auf einen Teiltext verkürzen.
procedure TMainForm.BtnAddExceptionClick(Sender: TObject);
var
  I, J: Integer;
  Textfolge: string;
begin
  I := CurrentHitIndex;
  if I < 0 then
  begin
    MessageDlg('Hinweis', 'Bitte zuerst einen Suchtreffer auswählen.',
      mtInformation, [mbOK], 0);
    Exit;
  end;

  Textfolge := Trim(FHits[I].MatchedLine);
  if Textfolge = '' then
  begin
    MessageDlg('Hinweis', 'Die ausgewählte Fundzeile ist leer.',
      mtInformation, [mbOK], 0);
    Exit;
  end;
  for J := 0 to MemoExceptions.Lines.Count - 1 do
    if Trim(MemoExceptions.Lines[J]) = Textfolge then
    begin
      StatusLabel.Caption := 'Diese Textfolge steht bereits in der Ausnahmeliste.';
      MemoExceptions.SetFocus;
      Exit;
    end;

  MemoExceptions.Lines.Add(Textfolge);
  CheckExceptions.Checked := True;
  SaveExceptions;
  StatusLabel.Caption := 'Treffer in Ausnahmeliste übernommen (gespeichert).';
  MemoExceptions.SetFocus;
  MemoExceptions.SelStart := Length(MemoExceptions.Text);
end;

procedure TMainForm.BtnOpenClick(Sender: TObject);
var
  I: Integer;
begin
  I := CurrentHitIndex;
  if I < 0 then
  begin
    MessageDlg('Hinweis', 'Bitte zuerst einen Suchtreffer auswählen.',
      mtInformation, [mbOK], 0);
    Exit;
  end;
  if not OpenDocument(FHits[I].FileName) then
    MessageDlg('Fehler', 'Die Datei konnte nicht geöffnet werden.',
      mtError, [mbOK], 0);
end;

procedure TMainForm.GridResultsDblClick(Sender: TObject);
begin
  BtnOpenClick(Sender);
end;


// Ersetzen ist absichtlich nur für eine wörtliche, groß-/kleinschreibungs-
// genaue Suche verfügbar. So stimmen die Treffer mit dem Ersatzalgorithmus überein.
function TMainForm.PrepareReplacement(const AFile, ASearch, AReplace: string;
  out AOriginal, AChanged: RawByteString; out ACount, ASkipped: Integer): Boolean;
var
  Stream: TFileStream;
  P, Q, StartPos, J, K, LastProtectedStart: SizeInt;
  SearchBytes, ReplaceBytes, ExceptionBytes: RawByteString;
  ProtectedStarts: array of Byte;
  IsProtected: Boolean;
begin
  Result := False;
  ACount := 0;
  ASkipped := 0;
  AOriginal := '';
  AChanged := '';
  if (not FileExists(AFile)) or (ASearch = '') then Exit;
  Stream := TFileStream.Create(AFile, fmOpenRead or fmShareDenyNone);
  try
    if (Stream.Size > MAX_REPLACE_FILE_BYTES) or (Stream.Size < 0) then
      raise Exception.Create('Datei größer als 16 MiB (Sicherheitsgrenze).');
    SetLength(AOriginal, SizeInt(Stream.Size));
    if Length(AOriginal) > 0 then
      Stream.ReadBuffer(AOriginal[1], Length(AOriginal));
  finally
    Stream.Free;
  end;
  if Pos(#0, AOriginal) > 0 then
    raise Exception.Create('Binärdatei mit Nullbytes – übersprungen.');
  SearchBytes := RawByteString(ASearch);
  ReplaceBytes := RawByteString(AReplace);

  // Jede Zeile in der Ausnahmeliste ist eine exakte, geschützte Textfolge.
  // Nur Suchvorkommen, die vollständig INNERHALB dieser Textfolge liegen,
  // werden ausgelassen. Andere Treffer auf derselben Zeile bleiben ersetzbar.
  if CheckExceptions.Checked then
  begin
    SetLength(ProtectedStarts, Length(AOriginal) + 1);
    for J := 0 to MemoExceptions.Lines.Count - 1 do
    begin
      ExceptionBytes := RawByteString(Trim(MemoExceptions.Lines[J]));
      if Length(ExceptionBytes) < Length(SearchBytes) then Continue;
      Q := 1;
      while Q <= Length(AOriginal) - Length(ExceptionBytes) + 1 do
      begin
        K := Pos(ExceptionBytes, Copy(AOriginal, Q, MaxInt));
        if K = 0 then Break;
        K := Q + K - 1;
        Q := K + 1;
        LastProtectedStart := K + Length(ExceptionBytes) - Length(SearchBytes);
        while K <= LastProtectedStart do
        begin
          ProtectedStarts[K] := 1;
          Inc(K);
        end;
        // Überlappende Ausnahmen ebenfalls berücksichtigen.
      end;
    end;
  end;

  StartPos := 1;
  while StartPos <= Length(AOriginal) do
  begin
    P := Pos(SearchBytes, Copy(AOriginal, StartPos, MaxInt));
    if P = 0 then Break;
    P := P + StartPos - 1;
    IsProtected := False;
    if Length(ProtectedStarts) > P then
      IsProtected := ProtectedStarts[P] <> 0;
    AChanged := AChanged + Copy(AOriginal, StartPos, P - StartPos);
    if IsProtected then
    begin
      AChanged := AChanged + SearchBytes;
      Inc(ASkipped);
    end
    else
    begin
      AChanged := AChanged + ReplaceBytes;
      Inc(ACount);
    end;
    StartPos := P + Length(SearchBytes);
  end;
  AChanged := AChanged + Copy(AOriginal, StartPos, MaxInt);
  Result := ACount > 0;
end;

procedure TMainForm.SaveReplacement(const AFile: string;
  const AOriginal, AChanged: RawByteString);
var
  BackupName, TempName: string;
  Stream: TFileStream;
  Attr: LongInt;
begin
  // Keine vorhandenen Sicherungsdateien überschreiben.
  BackupName := AFile + '.opengrep.bak';
  TempName := AFile + '.opengrep.tmp';
  if FileExists(BackupName) or FileExists(TempName) then
    raise Exception.Create('Sicherung oder temporäre Datei existiert bereits.');
  Attr := FileGetAttr(AFile);
  if (Attr < 0) then
    raise Exception.Create('Dateiattribute können nicht gelesen werden.');
  // Vor dem Schreiben erneut prüfen, ob die Datei seit der Vorschau verändert wurde.
  // Die Prüfung erfolgt zusätzlich vor der Sicherung in BtnReplaceClick.
  Stream := TFileStream.Create(BackupName, fmCreate);
  try
    if Length(AOriginal) > 0 then Stream.WriteBuffer(AOriginal[1], Length(AOriginal));
  finally
    Stream.Free;
  end;
  try
    Stream := TFileStream.Create(TempName, fmCreate);
    try
      if Length(AChanged) > 0 then Stream.WriteBuffer(AChanged[1], Length(AChanged));
    finally
      Stream.Free;
    end;
    FileSetAttr(TempName, Attr);
    if not RenameFile(TempName, AFile) then
      raise Exception.Create('Temporäre Datei konnte nicht umbenannt werden.');
  except
    if FileExists(TempName) then DeleteFile(TempName);
    raise;
  end;
end;

procedure TMainForm.BtnReplaceClick(Sender: TObject);
var
  Files: TStringList;
  Originals, Changes: array of RawByteString;
  Counts, SkippedCounts: array of Integer;
  I, N, Total, TotalSkipped, ReplacedFiles, Failed: Integer;
  FileName, Preview, Errors, SearchTerm, ReplaceTerm: string;
  BeforeNow, DummyChanged: RawByteString;
  CurrentCount, CurrentSkipped: Integer;
  Proceed: Boolean;
begin
  if FProcess <> nil then Exit;
  if not FSearchCompleted or (FHitCount = 0) then
  begin
    MessageDlg('Hinweis', 'Bitte zuerst eine vollständige, fehlerfreie Suche durchführen.',
      mtInformation, [mbOK], 0);
    Exit;
  end;
  if CheckRegex.Checked or (not CheckCase.Checked) or CheckWholeWord.Checked then
  begin
    MessageDlg('Sicherheitsregel',
      'Ersetzen ist nur bei wörtlicher Suche mit aktivierter '+
      'Groß-/Kleinschreibung und ohne Option "Ganze Wörter" möglich.' + LineEnding +
      'Bitte diese Optionen einstellen und erneut suchen.',
      mtInformation, [mbOK], 0);
    Exit;
  end;
  if EditSearch.Text <> FLastSearchText then
  begin
    MessageDlg('Hinweis', 'Der Suchbegriff wurde geändert. Bitte zuerst erneut suchen.',
      mtInformation, [mbOK], 0);
    Exit;
  end;
  // Nie einen alten Suchlauf durch einen später geänderten Zielpfad ersetzen.
  if (ExpandFileName(Trim(EditFolder.Text)) <> FLastTarget) or
     (CheckSingleFile.Checked <> FLastSingleFile) or
     (Trim(EditMask.Text) <> FLastMask) or
     (CheckSubdirs.Checked <> FLastSubdirs) or
     (CheckHidden.Checked <> FLastHidden) or
     (CheckCase.Checked <> FLastCase) or
     (CheckRegex.Checked <> FLastRegex) or
     (CheckWholeWord.Checked <> FLastWholeWord) then
  begin
    MessageDlg('Sicherheit',
      'Suchbereich oder Suchoptionen wurden nach der Suche geändert.' + LineEnding +
      'Bitte zuerst erneut suchen.', mtInformation, [mbOK], 0);
    Exit;
  end;
    SearchTerm := FLastSearchText;
  ReplaceTerm := EditReplace.Text;
  if SearchTerm = ReplaceTerm then
  begin
    MessageDlg('Hinweis', 'Such- und Ersatztext sind identisch.', mtInformation,
      [mbOK], 0);
    Exit;
  end;
  Files := TStringList.Create;
  try
    Files.Sorted := True;
    Files.Duplicates := dupIgnore;
    for I := 0 to FHitCount - 1 do Files.Add(FHits[I].FileName);
    SetLength(Originals, Files.Count);
    SetLength(Changes, Files.Count);
    SetLength(Counts, Files.Count);
    SetLength(SkippedCounts, Files.Count);
    Preview := '';
    Errors := '';
    Total := 0;
    TotalSkipped := 0;
    N := 0;
    for I := 0 to Files.Count - 1 do
    begin
      FileName := Files[I];
      try
        if PrepareReplacement(FileName, SearchTerm, ReplaceTerm,
          Originals[I], Changes[I], Counts[I], SkippedCounts[I]) then
        begin
          Inc(N);
          Inc(Total, Counts[I]);
          if N <= 15 then Preview := Preview + ExtractFileName(FileName) +
            ' (' + IntToStr(Counts[I]) + ')' + LineEnding;
        end;
        Inc(TotalSkipped, SkippedCounts[I]);
      except
        on E: Exception do
        begin
          Counts[I] := 0;
          if Length(Errors) < 1500 then
            Errors := Errors + FileName + ': ' + E.Message + LineEnding;
        end;
      end;
    end;
    if N = 0 then
    begin
      MessageDlg('Keine Änderungen', Format('Keine ersetzbaren Fundstellen gefunden. %d geschützt.', [TotalSkipped]) +
        LineEnding + Errors, mtInformation, [mbOK], 0);
      Exit;
    end;
    Proceed := MessageDlg('Ersetzen – Sicherheitsvorschau',
      Format('%d Vorkommen in %d Dateien ersetzen?', [Total, N]) +
      LineEnding + Format('%d Vorkommen durch Ausnahmeliste geschützt.', [TotalSkipped]) +
      LineEnding + LineEnding + 'Suche: ' + SearchTerm + LineEnding +
      'Ersatz: ' + ReplaceTerm + LineEnding + LineEnding +
      'Betroffene Dateien (max. 15 angezeigt):' + LineEnding + Preview +
      LineEnding + 'Für jede Datei wird eine Sicherung *.opengrep.bak erzeugt.' +
      LineEnding + 'Bereits vorhandene Sicherungen werden NICHT überschrieben.' +
      LineEnding + LineEnding + 'Änderungen jetzt durchführen?',
      mtConfirmation, [mbYes, mbNo], 0) = mrYes;
    if not Proceed then Exit;
    ReplacedFiles := 0;
    Failed := 0;
    for I := 0 to Files.Count - 1 do
    begin
      if Counts[I] = 0 then Continue;
      try
        // Erneut einlesen: Zwischen Vorschau und Ausführung könnten
        // externe Programme die Datei geändert haben.
        if not PrepareReplacement(Files[I], SearchTerm, ReplaceTerm,
          BeforeNow, DummyChanged, CurrentCount, CurrentSkipped) then
          raise Exception.Create('Treffer inzwischen verschwunden.');
        if (BeforeNow <> Originals[I]) or (CurrentCount <> Counts[I]) or
           (CurrentSkipped <> SkippedCounts[I]) then
          raise Exception.Create('Datei wurde seit der Vorschau verändert.');
        SaveReplacement(Files[I], Originals[I], Changes[I]);
        Inc(ReplacedFiles);
      except
        on E: Exception do
        begin
          Inc(Failed);
          if Length(Errors) < 2500 then
            Errors := Errors + Files[I] + ': ' + E.Message + LineEnding;
        end;
      end;
    end;
    FSearchCompleted := False; // Keine veralteten Treffer erneut ersetzen.
    StatusLabel.Caption := Format('%d Dateien geändert, %d übersprungen/fehlgeschlagen.',
      [ReplacedFiles, Failed]);
    MessageDlg('Ersetzen abgeschlossen',
      Format('%d Dateien geändert. %d Dateien fehlgeschlagen.',
        [ReplacedFiles, Failed]) + LineEnding +
      Format('%d Vorkommen geschützt.', [TotalSkipped]) + LineEnding +
      'Sicherungen: *.opengrep.bak' + LineEnding + LineEnding + Errors +
      LineEnding + 'Bitte die Suche erneut starten, um aktuelle Treffer zu sehen.',
      mtInformation, [mbOK], 0);
  finally
    Files.Free;
  end;
end;

end.
