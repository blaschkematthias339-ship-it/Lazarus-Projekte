# OpenGrepGUI 1.4 – Treffer direkt zur Ausnahmeliste hinzufügen

## Neu in Version 1.4

- Einen Treffer in der Tabelle einmal anklicken und dann **„Treffer zur Ausnahmeliste +“** drücken.
- Die vollständige angezeigte Fundzeile wird automatisch nach `MemoExceptions` übernommen.
- Bereits vorhandene identische Einträge werden nicht doppelt hinzugefügt.
- Die Option **„Ausnahmeliste beim Ersetzen verwenden“** wird eingeschaltet, und die Liste wird sofort gespeichert.
- Tipp: Für feinere Ausnahmen die eingefügte Zeile im Memo auf eine kurze, eindeutige Textfolge kürzen. Sonst schützt die vollständige Zeile alle in ihr enthaltenen Suchvorkommen.
- Der Doppelklick auf die Trefferliste öffnet weiterhin die Datei wie bisher.

## Neu in Version 1.3

- Die Checkbox **„Nur eine einzelne Datei bearbeiten“** im Hauptfenster einschalten.
- Dann mit **„Datei wählen“** genau eine Datei auswählen.
- **Suchen** zeigt nur Fundstellen in dieser Datei an. **Ersetzen** ändert nur diese Datei.
- Zum Wechsel zur Ordnersuche die Checkbox wieder ausschalten.
- Dateifilter, Unterordner und versteckte Dateien sind im Einzeldatei-Modus deaktiviert, da nicht relevant.
- Wird der Suchpfad oder der Suchmodus nach einer Suche verändert, muss vor dem Ersetzen neu gesucht werden.
- Bestehende Ausnahmeliste, Sicherheitsvorschau und `*.opengrep.bak`-Sicherungen bleiben erhalten.

## Neu in Version 1.2: Ausnahmen beim Ersetzen

- Die Checkbox **„Ausnahmeliste beim Ersetzen verwenden“** aktivieren.
- Im Feld rechts **eine vollständig zu schützende Textfolge pro Zeile** eingeben.
- Beispiel: Suchtext `Haus`, Ersatztext `Gebäude`, Ausnahmeliste `Haustür`: Das `Haus` in `Haustür` bleibt erhalten, aber ein eigenständiges `Haus` wird ersetzt.
- Auch mehrere unterschiedliche Textfolgen dürfen untereinander stehen. Groß-/Kleinschreibung muss exakt stimmen.
- **Nur Vorkommen innerhalb geschützter Textfolgen** werden ausgelassen. Andere Treffer in derselben Textzeile dürfen weiterhin ersetzt werden.
- Leere Zeilen werden ignoriert. Die Liste wirkt **nur beim Ersetzen**, die Suchergebnisliste zeigt weiterhin alle Treffer.
- Die Sicherheitsvorschau zeigt die Anzahl der ersetzbaren und der ausgenommenen Vorkommen.
- Die Liste einschließlich Aktivierung wird beim Schließen in `~/.config/OpenGrepGUI_Ausnahmen.txt` (bzw. dem Lazarus/FPC-App-Konfigurationsordner) gespeichert.

**Sicherheit:** Wie bisher werden vor dem Schreiben Sicherungen `*.opengrep.bak` erzeugt; vorhandene Sicherungen werden nicht überschrieben. Dateien über 16 MiB und Binärdateien werden nicht verändert. Eine wörtliche Suche mit aktivierter Groß-/Kleinschreibung ohne „Ganze Wörter“ ist für Ersetzen weiterhin erforderlich.

## Installation

Unter Ubuntu/KDE neon:

```bash
sudo apt update
sudo apt install ripgrep lazarus
```

Eine vorhandene Lazarus-Installation genügt ebenfalls. Das Projekt verwendet die LCL (Qt5/Qt6/GTK2 je nach Lazarus-Widgetset), FCL (`process`, `fpjson`, `jsonparser`) und sonst keine zusätzlichen Lazarus-Komponenten.

## Kompilieren

1. `OpenGrepGUI.lpi` in Lazarus öffnen.
2. Falls gewünscht: **Projekt → Projektoptionen → Compileroptionen → Additions and Overrides** überprüfen, dass das bereits installierte Widgetset verwendet wird.
3. **Start → Kompilieren** (`Strg+F9`) oder **Start → Starten** (`F9`).
4. Die Oberfläche lässt sich im Formulardesigner über `MainUnit.lfm` bearbeiten.

## Bedienung

1. Einen **Suchbegriff** eingeben.
2. Über **Ordner wählen** den Suchordner auswählen.
3. Optional einen **Dateifilter** wie `*.pas`, `*.txt` oder `*.md` eintragen (ein einzelnes ripgrep-Glob).
4. Optionen auswählen und **Suchen** drücken.
5. Treffer anklicken: Vorschau mit Zeilenkontext. Doppelklick oder **Ausgewählte Datei öffnen** öffnet die Datei in der standardmäßigen Anwendung.
6. Mit **Abbrechen** die laufende Suche beenden.

## Technische Hinweise

- ripgrep wird **direkt als Prozess ohne Shell** gestartet: Dateinamen und Suchbegriffe werden korrekt als getrennte Argumente übergeben.
- Suchdaten werden **nur gelesen**, nicht geändert.
- JSON-Ausgabe von `rg --json` wird ausgewertet; dadurch stören Doppelpunkte in Dateinamen und Trefferzeilen die Zerlegung nicht.
- Die Oberfläche bleibt dank eines Timers für die Prozessausgabe während der Suche bedienbar.
- Es werden maximal **20.000 Treffer** angezeigt; danach wird die Suche beendet. Die Vorschau lädt Dateien über **2 MB** nicht vollständig in den Speicher.
- Ripgrep ignoriert standardmäßig `.gitignore` und versteckte Dateien. Mit „Versteckte Dateien“ wird `--hidden` eingeschaltet; `.gitignore`-Regeln gelten weiterhin.
- Ein leerer Dateifilter bedeutet: alle von ripgrep berücksichtigten Dateitypen.
- „Groß-/Kleinschreibung“ **an** = exakte Schreibweise; **aus** = `--ignore-case`.
- „Regulärer Ausdruck“ **aus** = wörtliche Suche; **an** = regulärer Ausdruck.
- Trefferzeile, Zeilennummer und Datei werden angezeigt; Spaltenangaben entsprechen ripgrep-Bytepositionen und können bei Umlauten von Zeichenpositionen abweichen.
- Die Vorschau großer Dateien enthält nur die gefundene Zeile.
- Dateien, für die keine Leserechte bestehen, können nicht durchsucht werden. Fehler beim Lesen einzelner Dateien meldet ripgrep in der Fehlerausgabe.

## Projektdateien

- `OpenGrepGUI.lpr` – Programmstart
- `OpenGrepGUI.lpi` – Lazarus-Projekt
- `MainUnit.pas` – Suchlogik und Oberfläche
- `MainUnit.lfm` – visuell editierbares Formular

## Hinweise zur Version

Die Projektdateien wurden statisch geprüft, **nicht** mit Lazarus kompiliert: In der Erstellungsumgebung ist kein Lazarus-/Free-Pascal-Compiler installiert. Bitte beim ersten Start unter der eigenen Lazarus-Version testen.


## NEU in 1.1: Ersetzen

1. Für die erste Version des Ersetzens **Groß-/Kleinschreibung AN**, **Regulärer Ausdruck AUS**, **Ganze Wörter AUS** wählen.
2. Nach dem Suchen den Text bei **Ersetzen durch** eintragen (darf leer sein).
3. **Ersetzen ...** klicken. Eine Bestätigung zeigt Anzahl und betroffene Dateien.
4. Erst nach **Ja** werden Dateien geändert. Für jede wird eine Sicherung `<Dateiname>.opengrep.bak` angelegt.
5. Nach dem Ersetzen erneut suchen. Ein bestehendes Backup wird **nie überschrieben**; diese Datei wird stattdessen übersprungen.

Wichtig: Die Ersetzung geschieht **wörtlich und bytegenau** auf UTF-8-Textbasis, nicht mit Regex und nicht fallunabhängig. Es werden nur Dateien aus einer vollständig abgeschlossenen, fehlerfreien Suche berücksichtigt. Änderungen externer Programme zwischen Vorschau und Speicherung werden erkannt. Binärdateien mit Nullbytes und Dateien über 16 MiB sind ausgeschlossen. Die Sicherung liegt im selben Ordner; für sensible Daten zuerst an einer Kopie testen. Formate/Dateirechte bitte nach dem Test prüfen. Keine Garantie für Absturzsicherheit bei Stromausfall.

**Hinweis:** In dieser Umgebung ist kein Free-Pascal-/Lazarus-Compiler installiert. Bitte die neue Version wie gewohnt mit Lazarus kompilieren und testen.
